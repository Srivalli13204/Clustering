#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Surpress warnings


# In[2]:


def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn


# In[3]:


#importing libraries


# In[4]:


import random 
import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt 
from sklearn.cluster import KMeans 
from sklearn.datasets import make_blobs 
get_ipython().run_line_magic('matplotlib', 'inline')


# In[5]:


#creating our own dataset


# In[6]:


np.random.seed(0)


# In[7]:


X, y = make_blobs(n_samples=5000, centers=[[4,4], [-2, -1], [2, -3], [1, 1]], cluster_std=0.9)


# In[8]:


#scatter plot


# In[9]:


plt.scatter(X[:, 0], X[:, 1], marker='.')


# In[10]:


#setting up k-means


# In[11]:


k_means = KMeans(init = "k-means++", n_clusters = 4, n_init = 12)


# In[12]:


#fitting


# In[13]:


k_means.fit(X)


# In[14]:


#labels


# In[15]:


k_means_labels = k_means.labels_
k_means_labels


# In[16]:


#centers


# In[17]:


k_means_cluster_centers = k_means.cluster_centers_
k_means_cluster_centers


# In[18]:


#creating visual plots


# In[19]:


fig = plt.figure(figsize=(6, 4))
colors = plt.cm.Spectral(np.linspace(0, 1, len(set(k_means_labels))))
ax = fig.add_subplot(1, 1, 1)
for k, col in zip(range(len([[4,4], [-2, -1], [2, -3], [1, 1]])), colors):
    my_members = (k_means_labels == k)
    cluster_center = k_means_cluster_centers[k]
    ax.plot(X[my_members, 0], X[my_members, 1], 'w', markerfacecolor=col, marker='.')
    ax.plot(cluster_center[0], cluster_center[1], 'o', markerfacecolor=col,  markeredgecolor='k', markersize=6)
ax.set_title('KMeans')
plt.show()


# In[20]:


#3 clusters


# In[21]:


k_means3 = KMeans(init = "k-means++", n_clusters = 3, n_init = 12)
k_means3.fit(X)
fig = plt.figure(figsize=(6, 4))
colors = plt.cm.Spectral(np.linspace(0, 1, len(set(k_means3.labels_))))
ax = fig.add_subplot(1, 1, 1)
for k, col in zip(range(len(k_means3.cluster_centers_)), colors):
    my_members = (k_means3.labels_ == k)
    cluster_center = k_means3.cluster_centers_[k]
    ax.plot(X[my_members, 0], X[my_members, 1], 'w', markerfacecolor=col, marker='.')
    ax.plot(cluster_center[0], cluster_center[1], 'o', markerfacecolor=col,  markeredgecolor='k', markersize=6)
ax.set_title('KMeans')
plt.show()


# In[22]:


#loading the dataset


# In[23]:


df = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX9.csv")
df.head()


# In[24]:


#pre processing


# In[25]:


df = df.drop('Address', axis=1)
df.head()


# In[26]:


#normalizing


# In[27]:


from sklearn.preprocessing import StandardScaler
X = df.values[:,1:]
X = np.nan_to_num(X)
Clus_dataSet = StandardScaler().fit_transform(X)
Clus_dataSet


# In[28]:


#modelling


# In[29]:


clusterNum = 3
k_means = KMeans(init = "k-means++", n_clusters = clusterNum, n_init = 12)
k_means.fit(X)


# In[30]:


#labels


# In[31]:


labels = k_means.labels_
print(labels)


# In[32]:


#insights


# In[33]:


df["Clus_km"] = labels
df.head()


# In[34]:


df.groupby('Clus_km').mean()


# In[35]:


area = np.pi * (X[:, 1])**2  
plt.scatter(X[:, 0], X[:, 3], s=area, c=labels.astype(float), alpha=0.5)
plt.xlabel('Age', fontsize=18)
plt.ylabel('Income', fontsize=16)
plt.show()


# In[36]:


from mpl_toolkits.mplot3d import Axes3D
fig = plt.figure(1, figsize=(5, 5))
ax = fig.add_axes([0, 0, .95, 1], projection='3d')
ax.set_xlabel('Weight')
ax.set_ylabel('Age')
ax.set_zlabel('Income')
ax.view_init(elev=48, azim=134)
ax.scatter(X[:, 1], X[:, 0], X[:, 3], c=labels.astype(float))
plt.show()


# In[ ]:




