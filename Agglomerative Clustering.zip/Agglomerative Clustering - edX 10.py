#!/usr/bin/env python
# coding: utf-8

# In[1]:


#importing libraries


# In[2]:


import numpy as np 
import pandas as pd
from scipy import ndimage 
from scipy.cluster import hierarchy 
from scipy.spatial import distance_matrix 
from matplotlib import pyplot as plt 
from sklearn import manifold, datasets 
from sklearn.cluster import AgglomerativeClustering 
from sklearn.datasets import make_blobs 
get_ipython().run_line_magic('matplotlib', 'inline')


# In[3]:


#generating random data


# In[4]:


X1, y1 = make_blobs(n_samples=50, centers=[[4,4], [-2, -1], [1, 1], [10,4]], cluster_std=0.9)


# In[5]:


#scatter plot


# In[6]:


plt.scatter(X1[:, 0], X1[:, 1], marker='o') 


# In[7]:


#agglomerative clustering


# In[8]:


agglom = AgglomerativeClustering(n_clusters = 4, linkage = 'average')


# In[9]:


#fitting the model


# In[10]:


agglom.fit(X1,y1)


# In[11]:


#show clustering


# In[12]:


plt.figure(figsize=(6,4))
x_min, x_max = np.min(X1, axis=0), np.max(X1, axis=0)
X1 = (X1 - x_min) / (x_max - x_min)


# In[13]:


for i in range(X1.shape[0]):
    plt.text(X1[i, 0], X1[i, 1], str(y1[i]),
             color=plt.cm.nipy_spectral(agglom.labels_[i] / 10.),
             fontdict={'weight': 'bold', 'size': 9})


# In[14]:


#displaying plot


# In[15]:


plt.scatter(X1[:, 0], X1[:, 1], marker='.')
plt.show()


# In[16]:


#combined plot


# In[17]:


for i in range(X1.shape[0]):
    plt.text(X1[i, 0], X1[i, 1], str(y1[i]),
             color=plt.cm.nipy_spectral(agglom.labels_[i] / 10.),
             fontdict={'weight': 'bold', 'size': 9})
plt.xticks([])
plt.yticks([])
plt.scatter(X1[:, 0], X1[:, 1], marker='.')
plt.show()


# In[18]:


#distance matrix


# In[19]:


dist_matrix = distance_matrix(X1,X1) 
print(dist_matrix)


# In[20]:


#using complete linkage


# In[21]:


Z = hierarchy.linkage(dist_matrix, 'complete')


# In[22]:


#dendogram


# In[23]:


dendro = hierarchy.dendrogram(Z)


# In[24]:


#changing complete linkage to average


# In[25]:


Z = hierarchy.linkage(dist_matrix, 'average')


# In[26]:


#dendogram


# In[27]:


dendro = hierarchy.dendrogram(Z)


# In[28]:


#loading the dataset


# In[29]:


df = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX10.csv")
df.head()


# In[30]:


df.shape


# In[31]:


#data cleaning


# In[32]:


print ("Shape of dataset before cleaning: ", df.size)
df[[ 'sales', 'resale', 'type', 'price', 'engine_s',
       'horsepow', 'wheelbas', 'width', 'length', 'curb_wgt', 'fuel_cap',
       'mpg', 'lnsales']] = df[['sales', 'resale', 'type', 'price', 'engine_s',
       'horsepow', 'wheelbas', 'width', 'length', 'curb_wgt', 'fuel_cap',
       'mpg', 'lnsales']].apply(pd.to_numeric, errors='coerce')


# In[33]:


df = df.dropna()
df = df.reset_index(drop=True)
print ("Shape of dataset after cleaning: ", df.size)
df.head(5)


# In[34]:


#feature selection


# In[35]:


featureset = df[['engine_s',  'horsepow', 'wheelbas', 'width', 'length', 'curb_wgt', 'fuel_cap', 'mpg']]


# In[36]:


#normalization


# In[37]:


from sklearn.preprocessing import MinMaxScaler
x = featureset.values #returns a numpy array
min_max_scaler = MinMaxScaler()
feature_mtx = min_max_scaler.fit_transform(x)
feature_mtx


# In[38]:


#clustering using Scipy


# In[39]:


import scipy
leng = feature_mtx.shape[0]
D = scipy.zeros([leng,leng])
for i in range(leng):
    for j in range(leng):
        D[i,j] = scipy.spatial.distance.euclidean(feature_mtx[i], feature_mtx[j])
D


# In[40]:


#using complete


# In[41]:


import pylab
import scipy.cluster.hierarchy
Z = hierarchy.linkage(D, 'complete')


# In[42]:


from scipy.cluster.hierarchy import fcluster
max_d = 3
clusters = fcluster(Z, max_d, criterion='distance')
clusters


# In[43]:


#no of clusters


# In[44]:


from scipy.cluster.hierarchy import fcluster
k = 5
clusters = fcluster(Z, k, criterion='maxclust')
clusters


# In[45]:


#plotting a dendogram


# In[46]:


def llf(id):
    return '[%s %s %s]' % (df['manufact'][id], df['model'][id], int(float(df['type'][id])) )


# In[47]:


#figure


# In[48]:


fig = pylab.figure(figsize=(18,50))
dendro = hierarchy.dendrogram(Z,  leaf_label_func=llf, leaf_rotation=0, leaf_font_size =12, orientation = 'right')


# In[49]:


#clustering using scikit-learn


# In[50]:


from sklearn.metrics.pairwise import euclidean_distances
dist_matrix = euclidean_distances(feature_mtx,feature_mtx) 
print(dist_matrix)


# In[51]:


Z_using_dist_matrix = hierarchy.linkage(dist_matrix, 'complete')


# In[52]:


#plotting a dendogram


# In[53]:


def llf(id):
    return '[%s %s %s]' % (df['manufact'][id], df['model'][id], int(float(df['type'][id])) )    


# In[54]:


#figure


# In[55]:


fig = pylab.figure(figsize=(18,50))
dendro = hierarchy.dendrogram(Z_using_dist_matrix,  leaf_label_func=llf, leaf_rotation=0, leaf_font_size =12, orientation = 'right')


# In[56]:


#agglomerative


# In[57]:


agglom = AgglomerativeClustering(n_clusters = 6, linkage = 'complete')
agglom.fit(dist_matrix)
agglom.labels_


# In[58]:


#adding new field


# In[59]:


df['cluster_'] = agglom.labels_
df.head()


# In[60]:


#plotting


# In[61]:


import matplotlib.cm as cm
n_clusters = max(agglom.labels_)+1
colors = cm.rainbow(np.linspace(0, 1, n_clusters))
cluster_labels = list(range(0, n_clusters))


# In[62]:


plt.figure(figsize=(16,14))
for color, label in zip(colors, cluster_labels):
    subset = df[df.cluster_ == label]
    for i in subset.index:
            plt.text(subset.horsepow[i], subset.mpg[i],str(subset['model'][i]), rotation=25) 
    plt.scatter(subset.horsepow, subset.mpg, s= subset.price*10, c=color, label='cluster'+str(label),alpha=0.5)
plt.legend()
plt.title('Clusters')
plt.xlabel('horsepow')
plt.ylabel('mpg')


# In[63]:


#counting no of classes


# In[64]:


df.groupby(['cluster_','type'])['cluster_'].count()


# In[65]:


#characteristics of each cluster


# In[66]:


agg_cars = df.groupby(['cluster_','type'])['horsepow','engine_s','mpg','price'].mean()
agg_cars


# In[67]:


#plotting


# In[68]:


plt.figure(figsize=(16,10))
for color, label in zip(colors, cluster_labels):
    subset = agg_cars.loc[(label,),]
    for i in subset.index:
        plt.text(subset.loc[i][0]+5, subset.loc[i][2], 'type='+str(int(i)) + ', price='+str(int(subset.loc[i][3]))+'k')
    plt.scatter(subset.horsepow, subset.mpg, s=subset.price*20, c=color, label='cluster'+str(label))
plt.legend()
plt.title('Clusters')
plt.xlabel('horsepow')
plt.ylabel('mpg')


# In[ ]:




